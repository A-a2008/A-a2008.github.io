import pyautogui as gui
import csv
from cryptography.fernet import Fernet
import requests
import sys
import time
import webbrowser
from datetime import datetime
import pytz


def create_new_user():
    email, password, bot_prefix, bot_channel = gui.prompt("Your Discord email"), gui.password("Your Discord password "), gui.prompt("Your Bot's prefix"), gui.prompt("Pokemon catching channel url")
    is_correct = gui.confirm(text=f"Email: {email} \nPassword: {password}", title="Is this information correct")
    if is_correct == "Cancel":
        gui.alert("Since, your information wasn't right, we are exiting the program")
        sys.exit(0)
    f = Fernet(b'Iz6MwEn9ThbFEWRofCx1EPK69H0T57BsslMTmG1mN40=')
    gui.alert("You will be redirected to a web brower to add a bot. Please add that bot to the server you want to pokemons in")
    time.sleep(5)
    webbrowser.open_new_tab("https://discord.com/api/oauth2/authorize?client_id=946831329847283783&permissions=3072&scope=bot")
    encrypted_pass = f.encrypt(password.encode())
    print(encrypted_pass)
    row = [email, encrypted_pass.decode('UTF-8'), bot_prefix, bot_channel]
    with open("user_data.csv", 'a', newline="") as file:
        writer = csv.writer(file)
        writer.writerow(row)
    ist = pytz.timezone('Asia/Calcutta')
    date = str(datetime.date(datetime.now(ist)))
    print(date)
    r = requests.get(f"https://pokemoncatcher.pythonanywhere.com/add/{email}/{date}")
    print(r.json())

def create_new_user_spammer():
    email, password, bot_prefix, spam_channel = gui.prompt("Your Discord email"), gui.password("Your Discord password "), gui.prompt("Your Bot's prefix"), gui.prompt("Spam channel url")
    is_correct = gui.confirm(text=f"Email: {email} \nPassword: {password}", title="Is this information correct")
    if is_correct == "Cancel":
        gui.alert("Since, your information wasn't right, we are exiting the program")
        sys.exit(0)
    f = Fernet(b'Iz6MwEn9ThbFEWRofCx1EPK69H0T57BsslMTmG1mN40=')
    encrypted_pass = f.encrypt(password.encode())
    print(encrypted_pass)
    row = [email, encrypted_pass.decode('UTF-8'), bot_prefix, spam_channel]
    with open("user_data_spammer.csv", 'a', newline="") as file:
        writer = csv.writer(file)
        writer.writerow(row)
    ist = pytz.timezone('Asia/Calcutta')
    date = str(datetime.date(datetime.now(ist)))
    print(date)
    r = requests.get(f"https://pokemoncatcher.pythonanywhere.com/add/{email}/{date}")
    print(r.json())

def is_newuser():
    with open("user_data.csv", 'r') as file:
        reader = csv.reader(file)
        rows = []
        for row in reader:
            rows.append(row)
        rows = rows[1:]
        try:
            rows = rows[0]
            return False
        except IndexError:
            return True

def is_newuser_spammer():
    with open("user_data_spammer.csv", 'r') as file:
        reader = csv.reader(file)
        rows = []
        for row in reader:
            rows.append(row)
        rows = rows[1:]
        try:
            rows = rows[0]
            return False
        except IndexError:
            return True

def get_user_data():
    with open("user_data.csv", 'r') as file:
        reader = csv.reader(file)
        rows = []
        for row in reader:
            rows.append(row)
        rows = rows[1:]
        try:
            rows = rows[0]
            email, encrypted_pass, bot_prefix, bot_channel = rows[0], rows[1], rows[2], rows[3]
            f = Fernet(b'Iz6MwEn9ThbFEWRofCx1EPK69H0T57BsslMTmG1mN40=')
            decrypted = f.decrypt(encrypted_pass.encode())
            password = decrypted.decode("UTF-8")
            return email, password, bot_prefix, bot_channel
        except IndexError:
            return None, None, None, None, None

def get_user_data_spammer():
    with open("user_data_spammer.csv", 'r') as file:
        reader = csv.reader(file)
        rows = []
        for row in reader:
            rows.append(row)
        rows = rows[1:]
        try:
            rows = rows[0]
            email, encrypted_pass, bot_prefix, spam_channel = rows[0], rows[1], rows[2], rows[3]
            f = Fernet(b'Iz6MwEn9ThbFEWRofCx1EPK69H0T57BsslMTmG1mN40=')
            decrypted = f.decrypt(encrypted_pass.encode())
            password = decrypted.decode("UTF-8")
            return (email, password, bot_prefix, spam_channel)
        except IndexError:
            return None, None, None, None, None